<?php
//Shah Wiruddin
$count = 1;
while ($count <= 100)
{
//2255201031
  if ($count % 33 === 0) {
    echo $count . " is divisible by 33\n";
  }
  $count += 1;
}
//Kelas B