<?php
//Shah Wiruddin
  $plant_height = 22;
  do  {
    echo "The plant is $plant_height tall.\n";
//2255201031
    if ($plant_height >= 30) {
      echo "And can produce fruit.\n";
    }
    $plant_height ++;
  } while ($plant_height < 31);
//Kelas B