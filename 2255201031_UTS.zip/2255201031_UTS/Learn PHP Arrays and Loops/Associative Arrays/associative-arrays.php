<?php
//Shah Wiruddin
namespace Codecademy;

// Write your code below:
$php_array = array(
  "language" => "PHP", 
  "creator" => "Rasmus Lerdorf",
 "year_created" => 1995,
 "filename_extensions" => [".php", ".phtml", ".php3", ".php4", ".php5", ".php7", ".phps", ".php-s", ".pht", ".phar"],
);
//2255201031
print_r($php_array);

$php_short = [
  "language" => "PHP", 
  "creator" => "Rasmus Lerdorf", 
  "year_created" => 1995, 
  "filename_extensions" => [".php", ".phtml", ".php3", ".php4", ".php5", ".php7", ".phps", ".php-s", ".pht", ".phar"]
];
//Kelas B