<?php
//Shah Wiruddin
$message = ["Oh hey", " You're doing great", " Keep up the good work!\n"];
//2255201031
$favorite_nums = [7, 201, 33, 88, 91];
// Write your code below:
echo implode("1+3", $message);

print_r($favorite_nums);
//Kelas B