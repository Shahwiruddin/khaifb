<?php
//Shah Wiruddin
// Write your code below:
$first_array = array("hello", 88, "my", -12361.11, "friend");
//255201031
echo count($first_array); 
//Kelas B