<?php
//Shah Wiruddin
$treasure_hunt = ["garbage", "cat", 99, ["soda can", 8, ":)", "sludge", ["stuff", "lint", ["GOLD!"], "cave", "bat", "scorpion"], "rock"], "glitter", "moonlight", 2.11];
//2255201031  
echo $treasure_hunt[3][4][2][0];
//Kelas B                