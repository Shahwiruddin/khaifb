<?php
//Shah Wiruddin
$stack = ["wild success", "failure", "struggle"];
// Write your code below:
array_push($stack, "blocker","impediment");
//2255201031
print_r($stack);

array_pop($stack);
array_pop($stack);
array_pop($stack);
array_pop($stack);

print_r($stack);
//Kelas B