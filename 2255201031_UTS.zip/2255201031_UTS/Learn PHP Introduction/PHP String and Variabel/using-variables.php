<?php
//Shah Wiruddin
// Write your code below:
$name = "Shah Wiruddin";
$language = "Indonesia"; 
//2255201031
$name = "echo";
echo "I love concatenating " . $name;
 
$language = "echo";
echo "\nI love " . $language;  
//Kelas B