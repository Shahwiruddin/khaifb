<?php
//Shah Wiruddin
// Write your code below:
//2255201031
 echo "Hello, World!";
//Kelas B