<?php
//Shah Wiruddin
// Write your code below:   

//2255201031
//echo "\nMy name is:" 
echo "Code" . "cademy"; 
echo "\nMy name is:" . " Shah Wiruddin";
echo "\n" . "tur" . "duck" . "en";
//Kelas B