<?php
//Shah Wiruddin
// Write your code below:
//2255201031
echo "1. Teach PHP";
echo "\n2. Eat breakfast"; 
echo "\n3. Learn to have \"fun\"bobo"; 
/* Prints
1. Go to gym
2. Cook dinner
*/  
//Kelas B