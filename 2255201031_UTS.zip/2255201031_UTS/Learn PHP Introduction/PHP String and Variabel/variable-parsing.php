<?php
//Shah Wiruddin
// Fill in the blanks in the code below:
  $noun = "sombong";
  $adjective = "panjang";
  $verb = "memakai";
//2255201031
  echo "The world's most beloved $noun was very $adjective and loved to $verb every single day.";

//Fix the code below and uncomment it:

 echo "\nI have always been obsessed with {$noun} I'm {$adjective} I'm always {$verb} ";
//Kelas B