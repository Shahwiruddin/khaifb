<?php
//Shah Wiruddin
/* Imagine a lot of code here */  
  $very_bad_unclear_name = "15 chicken wings";
 
// Write your code here:
//2255201031
$order =& $very_bad_unclear_name;
$$order .= ", 1 cheeseburger";

$order .= ", 3 side salads";

  // Don't change the line below
  echo "\nYour order is: $very_bad_unclear_name.";
//Kelas B