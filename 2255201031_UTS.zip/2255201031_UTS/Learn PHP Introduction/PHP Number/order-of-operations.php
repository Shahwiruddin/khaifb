<?php
//Shah Wiruddin
// Write your code below:
//2255201031
 echo 94 - 4.25 + 7 - 23.50 * 1.2 + 20 / 4;
//Kelas B