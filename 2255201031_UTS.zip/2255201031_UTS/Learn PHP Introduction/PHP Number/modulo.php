<?php
//Shah Wiruddin
// Write your code below:
//2255201031
 echo 4 % 8; 
//Kelas B  