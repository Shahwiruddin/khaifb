<?php
//Shah Wiruddin
// Write your code below:
 $my_num = 12;

	$answer = $my_num;

	$answer += 2;

	$answer *= 2;
//2255201031
	$answer -= 2;

	$answer /= 2;

	$answer -= $my_num;

	echo $answer;
//Kelas B