<?php
//Shah Wiruddin
// Write your code below:
//2255201031
 echo 8.2 + 3.8;
//Kelas B  