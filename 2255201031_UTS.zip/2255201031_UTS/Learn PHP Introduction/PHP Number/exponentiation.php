<?php
//Shah Wiruddin
// Write your code below:
//2255201031
echo 8 ** 2; 
//Kelas B 