<h1>i love PHP</h1>
//Shah Wiruddin
<p>This HTML will get delivered as is</p>
<?php echo "<p>But this code is interpreted by PHP and turned into HTML</p>";?>
<?php echo "<ul><li>You can use any HTML tags,</li><li>like this list.</li></ul>";?>
//2255201031
<footer>
  <p>And this code is back in plain HTML</p>
</footer>
//Kelas B