<?php
//Shah Wiruddin
echo "Hello World";
//2255201031
//Kelas B